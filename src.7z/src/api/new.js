for (let index = 0; index < document.styleSheets.length; index++) {
    const element = document.styleSheets[index];
    element.disabled = true
}