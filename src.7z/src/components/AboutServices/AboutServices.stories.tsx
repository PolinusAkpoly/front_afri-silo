/* eslint-disable */
import AboutServices from './AboutServices';

export default {
  title: "AboutServices",
};

export const Default = () => <AboutServices />;

Default.story = {
  name: 'default',
};
