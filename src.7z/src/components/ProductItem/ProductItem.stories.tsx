/* eslint-disable */
//Generate with new-react-cli : Sat, 16 Jul 2022 16:12:57 GMT
//Free training on https://mudey.fr
import ProductItem from './ProductItem';

export default {
  title: "ProductItem",
};

export const Default = () => <ProductItem product />;

Default.story = {
  name: 'default',
};
























































//Generate with new-react-cli : Sat, 16 Jul 2022 16:12:57 GMT
//Free training on sur https://mudey.fr
//Teacher Profile : https://mudey.fr/user/espero-akpoli
//Teacher Email : eakpoli@mudey.fr
//Teacher WhatsApp : +33 7 77 67 41 57
