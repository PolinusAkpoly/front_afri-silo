/* eslint-disable */
//Generate with new-react-cli : Fri, 01 Jul 2022 15:57:04 GMT
//Free training on https://mudey.fr
import CookieModal from './CookieModal';

export default {
  title: "CookieModal",
};

export const Default = () => <CookieModal />;

Default.story = {
  name: 'default',
};
























































//Generate with new-react-cli : Fri, 01 Jul 2022 15:57:04 GMT
//Free training on sur https://mudey.fr
//Teacher Profile : https://mudey.fr/user/espero-akpoli
//Teacher Email : eakpoli@mudey.fr
//Teacher WhatsApp : +33 7 77 67 41 57
