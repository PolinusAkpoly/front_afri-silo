/* eslint-disable */
//Generate with new-react-cli : Sat, 16 Jul 2022 15:40:32 GMT
//Free training on https://mudey.fr
import HomeProducts from './HomeProducts';

export default {
  title: "HomeProducts",
};

export const Default = () => <HomeProducts />;

Default.story = {
  name: 'default',
};
























































//Generate with new-react-cli : Sat, 16 Jul 2022 15:40:32 GMT
//Free training on sur https://mudey.fr
//Teacher Profile : https://mudey.fr/user/espero-akpoli
//Teacher Email : eakpoli@mudey.fr
//Teacher WhatsApp : +33 7 77 67 41 57
