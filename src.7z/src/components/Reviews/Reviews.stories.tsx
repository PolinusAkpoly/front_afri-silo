/* eslint-disable */
import Reviews from './Reviews';

export default {
  title: "Reviews",
};

export const Default = () => <Reviews />;

Default.story = {
  name: 'default',
};
