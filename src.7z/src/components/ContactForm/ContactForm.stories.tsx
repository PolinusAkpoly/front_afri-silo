/* eslint-disable */
import ContactForm from './ContactForm';

export default {
  title: "ContactForm",
};

export const Default = () => <ContactForm />;

Default.story = {
  name: 'default',
};
