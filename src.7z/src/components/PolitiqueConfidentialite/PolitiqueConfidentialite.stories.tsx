/* eslint-disable */
import PolitiqueConfidentialite from './PolitiqueConfidentialite';

export default {
  title: "PolitiqueConfidentialite",
};

export const Default = () => <PolitiqueConfidentialite />;

Default.story = {
  name: 'default',
};
