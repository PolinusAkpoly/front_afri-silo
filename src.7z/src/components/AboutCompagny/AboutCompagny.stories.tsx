/* eslint-disable */
import AboutCompagny from './AboutCompagny';

export default {
  title: "AboutCompagny",
};

export const Default = () => <AboutCompagny />;

Default.story = {
  name: 'default',
};
