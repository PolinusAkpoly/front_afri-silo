/* eslint-disable */
import CallToAction from './CallToAction';

export default {
  title: "CallToAction",
};

export const Default = () => <CallToAction />;

Default.story = {
  name: 'default',
};
