/* eslint-disable */
import HeaderPage from './HeaderPage';

export default {
  title: "HeaderPage",
};

export const Default = () => <HeaderPage name="" />;

Default.story = {
  name: 'default',
};
