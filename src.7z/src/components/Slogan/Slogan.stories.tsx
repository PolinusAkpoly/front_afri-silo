/* eslint-disable */
import Slogan from './Slogan';

export default {
  title: "Slogan",
};

export const Default = () => <Slogan />;

Default.story = {
  name: 'default',
};
