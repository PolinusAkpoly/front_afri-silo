/* eslint-disable */
import Partenaires from './Partenaires';

export default {
  title: "Partenaires",
};

export const Default = () => <Partenaires />;

Default.story = {
  name: 'default',
};
