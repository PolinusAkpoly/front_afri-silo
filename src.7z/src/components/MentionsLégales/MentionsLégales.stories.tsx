/* eslint-disable */
import MentionsLégales from './MentionsLégales';

export default {
  title: "MentionsLégales",
};

export const Default = () => <MentionsLégales />;

Default.story = {
  name: 'default',
};
