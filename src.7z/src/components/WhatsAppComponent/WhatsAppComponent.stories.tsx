/* eslint-disable */
//Generate with new-react-cli : Sat, 16 Jul 2022 08:09:29 GMT
//Free training on https://mudey.fr
import WhatsAppComponent from './WhatsAppComponent';

export default {
  title: "WhatsAppComponent",
};

export const Default = () => <WhatsAppComponent />;

Default.story = {
  name: 'default',
};
























































//Generate with new-react-cli : Sat, 16 Jul 2022 08:09:29 GMT
//Free training on sur https://mudey.fr
//Teacher Profile : https://mudey.fr/user/espero-akpoli
//Teacher Email : eakpoli@mudey.fr
//Teacher WhatsApp : +33 7 77 67 41 57
