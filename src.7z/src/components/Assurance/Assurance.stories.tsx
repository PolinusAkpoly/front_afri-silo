/* eslint-disable */
import Assurance from './Assurance';

export default {
  title: "Assurance",
};

export const Default = () => <Assurance />;

Default.story = {
  name: 'default',
};
