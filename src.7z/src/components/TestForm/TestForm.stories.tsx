/* eslint-disable */
//Generate with new-react-cli : Sun, 03 Jul 2022 13:44:28 GMT
//Free training on https://mudey.fr
import TestForm from './TestForm';

export default {
  title: "TestForm",
};

export const Default = () => <TestForm />;

Default.story = {
  name: 'default',
};
























































//Generate with new-react-cli : Sun, 03 Jul 2022 13:44:28 GMT
//Free training on sur https://mudey.fr
//Teacher Profile : https://mudey.fr/user/espero-akpoli
//Teacher Email : eakpoli@mudey.fr
//Teacher WhatsApp : +33 7 77 67 41 57
