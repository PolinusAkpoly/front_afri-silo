/* eslint-disable */
import CGV from './CGV';

export default {
  title: "CGV",
};

export const Default = () => <CGV />;

Default.story = {
  name: 'default',
};
