/* eslint-disable */
import Box from './Box';

export default {
  title: "Box",
};

export const Default = () => <Box />;

Default.story = {
  name: 'default',
};
