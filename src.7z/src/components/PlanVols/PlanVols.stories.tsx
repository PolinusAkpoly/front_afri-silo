/* eslint-disable */
import PlanVols from './PlanVols';

export default {
  title: "PlanVols",
};

export const Default = () => <PlanVols />;

Default.story = {
  name: 'default',
};
