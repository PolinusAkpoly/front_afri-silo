/* eslint-disable */
import Home from './Home';

export default {
  title: "Home",
};

export const Default = () => <Home />;

Default.story = {
  name: 'default',
};
