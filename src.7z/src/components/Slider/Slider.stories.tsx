/* eslint-disable */
import Slider from './Slider';

export default {
  title: "Slider",
};

export const Default = () => <Slider />;

Default.story = {
  name: 'default',
};
