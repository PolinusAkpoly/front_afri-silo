/* eslint-disable */
import About from './AboutContent';

export default {
  title: "About",
};

export const Default = () => <About />;

Default.story = {
  name: 'default',
};
