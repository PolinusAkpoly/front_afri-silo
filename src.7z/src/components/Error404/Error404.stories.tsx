/* eslint-disable */
import Error404 from './Error404';

export default {
  title: "Error404",
};

export const Default = () => <Error404 />;

Default.story = {
  name: 'default',
};
