export interface ProductList {
    _id: string
    name: string
}