export interface Column {
    name: string;
    value?: string;
  }
  