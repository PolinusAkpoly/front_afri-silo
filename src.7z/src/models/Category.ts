

export interface  Category{
    _id?: string 
    name: string 
    slug?: string
    description?: string 
    updated_at: Date | string | null
    created_at: Date | string | null
}