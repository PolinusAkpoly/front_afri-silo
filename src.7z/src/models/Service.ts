export interface Service {
    _id?: string
    icon: string
    imageUrl: string
    title: string
    description: string
    link: string
    slug: string
}